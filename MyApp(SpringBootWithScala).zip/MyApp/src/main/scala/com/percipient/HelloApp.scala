package com.percipient

import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class HelloApp {
  
}