package com.percipient

import org.springframework.boot.SpringApplication

object Hello {
  def main(args: Array[String]) = {
    SpringApplication run classOf[HelloApp]
    
    println("How r u")
  }
}
